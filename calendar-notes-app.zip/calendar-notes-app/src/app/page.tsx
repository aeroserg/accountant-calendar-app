// src/app/page.tsx
'use client'

import { redirect } from 'next/navigation';
import { useEffect } from 'react';

const RootPage = () => {
  useEffect(() => {
    redirect('/calendar');
  }, []);

  return (<div>Загрузка...</div>)
};

export default RootPage;